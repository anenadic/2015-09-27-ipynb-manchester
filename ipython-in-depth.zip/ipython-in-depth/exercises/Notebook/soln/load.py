%matplotlib inline

%load http://matplotlib.org/mpl_examples/api/hinton_demo.py
