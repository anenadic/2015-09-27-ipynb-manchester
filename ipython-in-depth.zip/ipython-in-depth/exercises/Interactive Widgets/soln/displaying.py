from IPython.html.widgets import *
from IPython.display import display
w = TextWidget(value="test")
display(w)
w.keys
